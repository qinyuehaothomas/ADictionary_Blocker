## *Hi*😂*I am Thomas!*

*A little about myself...*  
**Hometown :** Hong Kong, China  
**Age :** 14  
**English Level ...**<sub>Below sea level</sub>  
**Hobby :** Computer<sup>and almost evrything about it.</sup>  
- [X] Games  
- [X] Surfing Youtube
- [X] Talking in computer languages
- [ ] Facebook
- [ ] Discord
- [ ] ..... I guess not everything.

## My Project!:
<h2> <b>ADictionary Blocker!!</b> </h2>

***Reason :***
> Theres online reserch in school, **in english**.
> And my brain become jellly when i am reading.
> I **Don't** want to go back and forth for words.

***Functions :***
> You can search word by just **clicking** on it!
> You can add it to your **wordlist**!
> Ads will be replaced with word from your wordlist
> to help you **revise**

**Files**
> there's only  single file called *ADictionary_Blocker_V5*
> which will be installed in Tampermonkey / Geasermonkey to implyment the functions

#  Lets watch the [Video](https://youtu.be/w1yiLb6y1Ok "It sucks,I know")! 

##  Here's how to use it: 

1. Download the code to ***Tampermonkey / Geasermonkey*** OR [Click this](https://greasyfork.org/scripts/432144-adictionary-blocker/code/ADictionary%20Blocker.user.js) to finish in one step (if you have intsalled Tampermonkey / Geasermonkey)
1. Enable it,
1. Click on any word you don't know on any page(Some does not work...)
1. if you want to add to wordlist:
    1. click the grey tick.

## Now you have a breif idea on how to use it



<h1> Thanks for coming😁 </h1>
